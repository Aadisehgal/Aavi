export const COLORS = {
  background: '#0A0E27',
  surface: '#11183A',
  surfaceLight: '#1A2247',
  primary: '#00D4FF',
  primaryDark: '#0099CC',
  accent: '#FF6B35',
  text: '#E0E6F1',
  textSecondary: '#8B95B8',
  success: '#00E676',
  error: '#FF1744',
  warning: '#FFD600',
  border: '#1E2A4A',
  card: '#0F1630',
};

export const FONTS = {
  regular: 'sans-serif',
  medium: 'sans-serif-medium',
  bold: 'sans-serif-condensed',
};

export const SHADOWS = {
  glow: {
    shadowColor: '#00D4FF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 10,
  },
};
