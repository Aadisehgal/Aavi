import React, { useState, useRef, useCallback } from 'react';
import {
  View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { BannerAd, BannerAdSize } from 'react-native-google-mobile-ads';
import aiClient from '../aiClient';
import SelfHealingEngine from '../SelfHealingEngine';
import { COLORS } from '../theme';

const BANNER_ID = 'ca-app-pub-3684441716460567/7116352504';

export default function ChatScreen() {
  const [messages, setMessages] = useState([
    { id: '1', role: 'assistant', text: 'Hello sir. MANU AI at your service. How can I assist you today?' },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [streamingText, setStreamingText] = useState('');
  const flatListRef = useRef(null);

  const sendMessage = useCallback(async () => {
    if (!inputText.trim() || isLoading) return;
    const userMessage = { id: Date.now().toString(), role: 'user', text: inputText.trim() };
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);
    setStreamingText('');

    const parsed = SelfHealingEngine.parseCommand(userMessage.text);
    if (parsed) {
      const result = await SelfHealingEngine.executeCommand(parsed.intent, parsed.params);
      const responseText = result.success
        ? result.message
        : `I could not execute that command. ${result.error}\n\n${result.suggestion || ''}`;
      setMessages(prev => [...prev, { id: (Date.now()+1).toString(), role: 'assistant', text: responseText }]);
      setIsLoading(false);
      return;
    }

    const chatMessages = [
      { role: 'system', content: 'You are MANU AI, a Jarvis-style personal automation assistant. Be concise and helpful.' },
      ...messages.filter(m => m.role !== 'system').map(m => ({ role: m.role, content: m.text })),
      { role: 'user', content: userMessage.text },
    ];

    let currentText = '';
    await aiClient.streamChatCompletion(
      chatMessages,
      (chunk) => { currentText += chunk; setStreamingText(currentText); },
      (error) => {
        setMessages(prev => [...prev, { id: (Date.now()+1).toString(), role: 'assistant', text: `Error: ${error}` }]);
        setIsLoading(false); setStreamingText('');
      },
      () => {
        if (currentText) {
          setMessages(prev => [...prev, { id: (Date.now()+1).toString(), role: 'assistant', text: currentText }]);
        }
        setIsLoading(false); setStreamingText('');
      }
    );
  }, [inputText, isLoading, messages]);

  const stopGeneration = () => { aiClient.stopGeneration(); setIsLoading(false); setStreamingText(''); };

  const renderMessage = ({ item }) => (
    <View style={[styles.messageBubble, item.role === 'user' ? styles.userBubble : styles.assistantBubble]}>
      <Text style={[styles.messageText, item.role === 'user' ? styles.userText : styles.assistantText]}>{item.text}</Text>
    </View>
  );

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <FlatList ref={flatListRef} data={messages} renderItem={renderMessage} keyExtractor={item => item.id}
        contentContainerStyle={styles.messagesContainer}
        onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })} />
      {streamingText ? (
        <View style={[styles.messageBubble, styles.assistantBubble]}>
          <Text style={styles.messageText}>{streamingText}</Text>
          <Text style={styles.streamingDot}>●</Text>
        </View>
      ) : null}
      {isLoading && !streamingText ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator color={COLORS.primary} />
          <Text style={styles.loadingText}>MANU AI is thinking...</Text>
        </View>
      ) : null}
      <View style={styles.inputContainer}>
        <TextInput style={styles.input} value={inputText} onChangeText={setInputText}
          placeholder="Type a command or question..." placeholderTextColor={COLORS.textSecondary}
          multiline maxLength={500} onSubmitEditing={sendMessage} />
        {isLoading ? (
          <TouchableOpacity style={styles.stopButton} onPress={stopGeneration}>
            <Text style={styles.stopButtonText}>■</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
            <Text style={styles.sendButtonText}>➤</Text>
          </TouchableOpacity>
        )}
      </View>
      <BannerAd unitId={BANNER_ID} size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER} />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  messagesContainer: { padding: 15, paddingBottom: 20 },
  messageBubble: { maxWidth: '85%', padding: 12, borderRadius: 16, marginBottom: 10 },
  userBubble: { alignSelf: 'flex-end', backgroundColor: COLORS.primaryDark, borderBottomRightRadius: 4 },
  assistantBubble: { alignSelf: 'flex-start', backgroundColor: COLORS.surface, borderBottomLeftRadius: 4, borderWidth: 1, borderColor: COLORS.border },
  messageText: { color: COLORS.text, fontSize: 14, lineHeight: 20 },
  userText: { color: '#fff' },
  assistantText: { color: COLORS.text },
  streamingDot: { color: COLORS.primary, fontSize: 10, marginTop: 5 },
  loadingContainer: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', marginLeft: 15, marginBottom: 10 },
  loadingText: { color: COLORS.textSecondary, marginLeft: 10, fontSize: 12 },
  inputContainer: { flexDirection: 'row', alignItems: 'center', padding: 10, borderTopWidth: 1, borderTopColor: COLORS.border, backgroundColor: COLORS.surface },
  input: { flex: 1, backgroundColor: COLORS.background, borderRadius: 20, paddingHorizontal: 15, paddingVertical: 10, color: COLORS.text, fontSize: 14, maxHeight: 100, borderWidth: 1, borderColor: COLORS.border },
  sendButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center', marginLeft: 10 },
  sendButtonText: { color: '#fff', fontSize: 18 },
  stopButton: { width: 44, height: 44, borderRadius: 22, backgroundColor: COLORS.error, justifyContent: 'center', alignItems: 'center', marginLeft: 10 },
  stopButtonText: { color: '#fff', fontSize: 14, fontWeight: 'bold' },
});
