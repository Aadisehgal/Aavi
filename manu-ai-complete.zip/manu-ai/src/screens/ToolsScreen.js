import React, { useState } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet, Alert, Modal,
} from 'react-native';
import { BannerAd, BannerAdSize } from 'react-native-google-mobile-ads';
import TerminalManager from '../TerminalManager';
import { COLORS } from '../theme';

const BANNER_ID = 'ca-app-pub-3684441716460567/7116352504';

export default function ToolsScreen() {
  const [selectedTool, setSelectedTool] = useState(null);
  const categories = TerminalManager.getToolCategories();

  const runTool = (tool, category) => {
    if (category.rootRequired) {
      Alert.alert(
        'Root Required',
        `${tool} requires root access. Without root, only limited functionality is available.`,
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Run Anyway', onPress: () => executeTool(tool) },
        ]
      );
    } else {
      executeTool(tool);
    }
  };

  const executeTool = async (tool) => {
    const result = await TerminalManager.executeCommand(tool);
    Alert.alert('Tool Output', result.success ? result.message : result.error);
  };

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.header}>Tools Arsenal</Text>
        <Text style={styles.subheader}>30+ Ethical & Security Tools</Text>
        {categories.map((cat, idx) => (
          <View key={idx} style={styles.categoryCard}>
            <View style={styles.categoryHeader}>
              <Text style={styles.categoryName}>{cat.name}</Text>
              {cat.rootRequired && <Text style={styles.rootBadge}>⚠️ ROOT</Text>}
            </View>
            <Text style={styles.categoryNote}>{cat.note}</Text>
            <View style={styles.toolsGrid}>
              {cat.tools.map((tool, tIdx) => (
                <TouchableOpacity key={tIdx} style={styles.toolButton} onPress={() => runTool(tool, cat)}>
                  <Text style={styles.toolName}>{tool}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}
        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>ℹ️ What's Possible Without Root</Text>
          <Text style={styles.infoText}>• System & Utility tools work fully{'
'}• Network scanning works (limited){'
'}• Steganography & Crypto work fully{'
'}• Wireless tools need root for monitor mode{'
'}• Cannot access other apps' private data</Text>
        </View>
      </ScrollView>
      <BannerAd unitId={BANNER_ID} size={BannerAdSize.ANCHORED_ADAPTIVE_BANNER} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  scrollContent: { padding: 15, paddingBottom: 30 },
  header: { color: COLORS.primary, fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginBottom: 5 },
  subheader: { color: COLORS.textSecondary, fontSize: 14, textAlign: 'center', marginBottom: 20 },
  categoryCard: { backgroundColor: COLORS.card, borderRadius: 12, padding: 15, marginBottom: 15, borderWidth: 1, borderColor: COLORS.border },
  categoryHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  categoryName: { color: COLORS.primary, fontSize: 16, fontWeight: 'bold' },
  rootBadge: { color: COLORS.warning, fontSize: 11, fontWeight: 'bold' },
  categoryNote: { color: COLORS.textSecondary, fontSize: 11, marginBottom: 10, fontStyle: 'italic' },
  toolsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  toolButton: { backgroundColor: COLORS.surface, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 8, borderWidth: 1, borderColor: COLORS.border },
  toolName: { color: COLORS.text, fontSize: 12, fontFamily: 'monospace' },
  infoBox: { backgroundColor: 'rgba(0,212,255,0.05)', borderRadius: 12, padding: 15, borderWidth: 1, borderColor: COLORS.primary, marginTop: 10 },
  infoTitle: { color: COLORS.primary, fontSize: 14, fontWeight: 'bold', marginBottom: 8 },
  infoText: { color: COLORS.textSecondary, fontSize: 12, lineHeight: 20 },
});
