import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, Dimensions, Animated, Vibration,
  StatusBar, Platform,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Avatar3D from '../components/Avatar3D';
import { COLORS } from '../theme';

const { width, height } = Dimensions.get('window');

export default function DashboardScreen() {
  const navigation = useNavigation();
  const [isListening, setIsListening] = useState(false);
  const [voiceVerified, setVoiceVerified] = useState(false);
  const [statusText, setStatusText] = useState('MANU AI Ready');
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const ringAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    StatusBar.setBarStyle('light-content');
    if (Platform.OS === 'android') {
      StatusBar.setBackgroundColor(COLORS.background);
    }
    startPulseAnimation();
  }, []);

  const startPulseAnimation = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.1, duration: 1500, useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 1500, useNativeDriver: true }),
      ])
    ).start();
  };

  const handleVoicePress = () => {
    setIsListening(true);
    Vibration.vibrate(100);
    setStatusText('Listening...');

    Animated.timing(ringAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();

    setTimeout(() => {
      setIsListening(false);
      setStatusText('MANU AI Ready');
      Animated.timing(ringAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    }, 3000);
  };

  const buttons = [
    { label: 'AI Chat', icon: '💬', screen: 'Chat', color: COLORS.primary },
    { label: 'Terminal', icon: '💻', screen: 'Terminal', color: '#00E676' },
    { label: 'Tools', icon: '🛠️', screen: 'Tools', color: '#FF6B35' },
    { label: 'Settings', icon: '⚙️', screen: 'Settings', color: '#FFD600' },
  ];

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.background} />

      {/* Background Grid Effect */}
      <View style={styles.gridOverlay} />

      {/* Top Status */}
      <View style={styles.header}>
        <Text style={styles.statusText}>{statusText}</Text>
        {voiceVerified && (
          <View style={styles.verifiedBadge}>
            <Text style={styles.verifiedText}>✓ Voice Verified</Text>
          </View>
        )}
      </View>

      {/* Center Avatar */}
      <View style={styles.avatarContainer}>
        <Animated.View style={[
          styles.glowRing,
          {
            transform: [{ scale: pulseAnim }],
            opacity: isListening ? 0.8 : 0.3,
          }
        ]} />

        <Animated.View style={[
          styles.waveRing,
          {
            transform: [{ scale: Animated.add(1, Animated.multiply(ringAnim, 2)) }],
            opacity: Animated.multiply(ringAnim, 0.5),
          }
        ]} />

        <Avatar3D size={180} />

        {isListening && (
          <View style={styles.listeningIndicator}>
            <View style={styles.waveformBar} />
            <View style={[styles.waveformBar, { height: 30 }]} />
            <View style={[styles.waveformBar, { height: 20 }]} />
            <View style={[styles.waveformBar, { height: 35 }]} />
            <View style={[styles.waveformBar, { height: 15 }]} />
          </View>
        )}
      </View>

      {/* Title */}
      <Text style={styles.title}>MANU AI</Text>
      <Text style={styles.subtitle}>Personal Automation Engine</Text>

      {/* Voice Button */}
      <TouchableOpacity
        style={[styles.voiceButton, isListening && styles.voiceButtonActive]}
        onPress={handleVoicePress}
        activeOpacity={0.8}
      >
        <Text style={styles.voiceIcon}>🎙️</Text>
      </TouchableOpacity>

      {/* Navigation Buttons */}
      <View style={styles.buttonGrid}>
        {buttons.map((btn, index) => (
          <TouchableOpacity
            key={index}
            style={[styles.navButton, { borderColor: btn.color }]}
            onPress={() => navigation.navigate(btn.screen)}
            activeOpacity={0.7}
          >
            <Text style={[styles.navIcon, { color: btn.color }]}>{btn.icon}</Text>
            <Text style={[styles.navLabel, { color: btn.color }]}>{btn.label}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    alignItems: 'center',
    paddingTop: 40,
  },
  gridOverlay: {
    ...StyleSheet.absoluteFillObject,
    opacity: 0.03,
    backgroundColor: 'transparent',
  },
  header: {
    width: '100%',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  statusText: {
    color: COLORS.primary,
    fontSize: 14,
    fontFamily: 'monospace',
    letterSpacing: 2,
  },
  verifiedBadge: {
    marginTop: 5,
    backgroundColor: 'rgba(0, 230, 118, 0.2)',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.success,
  },
  verifiedText: {
    color: COLORS.success,
    fontSize: 11,
  },
  avatarContainer: {
    width: 220,
    height: 220,
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 20,
  },
  glowRing: {
    position: 'absolute',
    width: 200,
    height: 200,
    borderRadius: 100,
    borderWidth: 2,
    borderColor: COLORS.primary,
    backgroundColor: 'rgba(0, 212, 255, 0.05)',
  },
  waveRing: {
    position: 'absolute',
    width: 200,
    height: 200,
    borderRadius: 100,
    borderWidth: 1,
    borderColor: COLORS.primary,
  },
  listeningIndicator: {
    position: 'absolute',
    bottom: -30,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  waveformBar: {
    width: 4,
    height: 15,
    backgroundColor: COLORS.primary,
    borderRadius: 2,
  },
  title: {
    color: COLORS.primary,
    fontSize: 32,
    fontWeight: 'bold',
    letterSpacing: 4,
    textShadowColor: COLORS.primary,
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
  },
  subtitle: {
    color: COLORS.textSecondary,
    fontSize: 12,
    marginTop: 5,
    letterSpacing: 1,
  },
  voiceButton: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: COLORS.surface,
    borderWidth: 2,
    borderColor: COLORS.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 20,
    shadowColor: COLORS.primary,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 15,
    elevation: 10,
  },
  voiceButtonActive: {
    backgroundColor: 'rgba(0, 212, 255, 0.2)',
    borderColor: COLORS.success,
    shadowColor: COLORS.success,
  },
  voiceIcon: {
    fontSize: 28,
  },
  buttonGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 15,
    paddingHorizontal: 20,
    marginTop: 10,
  },
  navButton: {
    width: (width - 70) / 2,
    height: 80,
    backgroundColor: COLORS.card,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: COLORS.border,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  navIcon: {
    fontSize: 24,
    marginBottom: 5,
  },
  navLabel: {
    fontSize: 13,
    fontWeight: '600',
  },
});
