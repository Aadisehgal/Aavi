import React, { useState, useRef, useEffect } from 'react';
import {
  View, Text, TextInput, ScrollView, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, Clipboard, Alert,
} from 'react-native';
import TerminalManager from '../TerminalManager';
import { COLORS } from '../theme';

export default function TerminalScreen() {
  const [output, setOutput] = useState([
    'MANU AI Terminal v1.0',
    'Type "help" for available commands',
    'For real shell: Install Termux and run "termux-shell"',
    '─────────────────────────────────',
    '',
  ]);
  const [command, setCommand] = useState('');
  const [history, setHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const scrollViewRef = useRef(null);

  useEffect(() => {
    const removeListener = TerminalManager.addOutputListener((line) => {
      setOutput(prev => [...prev, line]);
    });
    return () => removeListener();
  }, []);

  useEffect(() => {
    scrollViewRef.current?.scrollToEnd({ animated: true });
  }, [output]);

  const executeCommand = async () => {
    if (!command.trim()) return;
    const cmd = command.trim();
    setOutput(prev => [...prev, `$ ${cmd}`]);
    setHistory(prev => [...prev, cmd]);
    setHistoryIndex(-1);
    setCommand('');

    if (cmd === 'clear') {
      setOutput(['Terminal cleared.']);
      return;
    }
    if (cmd === 'termux-shell') {
      const result = await TerminalManager.startShell();
      setOutput(prev => [...prev, result.success ? 'Shell started.' : `Error: ${result.error}`]);
      return;
    }
    if (cmd === 'exit') {
      const result = await TerminalManager.stopShell();
      setOutput(prev => [...prev, result.success ? 'Shell stopped.' : `Error: ${result.error}`]);
      return;
    }

    const result = await TerminalManager.executeCommand(cmd);
    setOutput(prev => [...prev, result.success ? result.message : `Error: ${result.error}`]);
  };

  const handleKeyPress = ({ nativeEvent }) => {
    if (nativeEvent.key === 'ArrowUp') {
      if (historyIndex < history.length - 1) {
        const newIndex = historyIndex + 1;
        setHistoryIndex(newIndex);
        setCommand(history[history.length - 1 - newIndex]);
      }
    } else if (nativeEvent.key === 'ArrowDown') {
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        setCommand(history[history.length - 1 - newIndex]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setCommand('');
      }
    }
  };

  const copyOutput = () => {
    Clipboard.setString(output.join('\n'));
    Alert.alert('Copied', 'Terminal output copied to clipboard');
  };

  const clearTerminal = () => setOutput(['Terminal cleared.']);

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={styles.toolbar}>
        <TouchableOpacity style={styles.toolButton} onPress={copyOutput}>
          <Text style={styles.toolButtonText}>📋 Copy</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.toolButton} onPress={clearTerminal}>
          <Text style={styles.toolButtonText}>🗑️ Clear</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.toolButton} onPress={() => setCommand('termux-shell')}>
          <Text style={styles.toolButtonText}>🔌 Termux</Text>
        </TouchableOpacity>
      </View>
      <ScrollView ref={scrollViewRef} style={styles.outputContainer} contentContainerStyle={styles.outputContent}>
        {output.map((line, index) => (
          <Text key={index} style={[
            styles.outputLine,
            line.startsWith('$') ? styles.commandLine : null,
            line.startsWith('Error:') ? styles.errorLine : null,
          ]}>{line}</Text>
        ))}
      </ScrollView>
      <View style={styles.inputContainer}>
        <Text style={styles.prompt}>$</Text>
        <TextInput
          style={styles.input}
          value={command}
          onChangeText={setCommand}
          onSubmitEditing={executeCommand}
          placeholder="Enter command..."
          placeholderTextColor={COLORS.textSecondary}
          autoCapitalize="none"
          autoCorrect={false}
          onKeyPress={handleKeyPress}
        />
        <TouchableOpacity style={styles.runButton} onPress={executeCommand}>
          <Text style={styles.runButtonText}>▶</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#000' },
  toolbar: { flexDirection: 'row', padding: 8, backgroundColor: COLORS.surface, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  toolButton: { paddingHorizontal: 12, paddingVertical: 6, backgroundColor: COLORS.surfaceLight, borderRadius: 6, marginRight: 8 },
  toolButtonText: { color: COLORS.primary, fontSize: 12 },
  outputContainer: { flex: 1, padding: 10 },
  outputContent: { paddingBottom: 20 },
  outputLine: { color: '#00FF00', fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace', fontSize: 12, lineHeight: 18 },
  commandLine: { color: COLORS.primary, fontWeight: 'bold' },
  errorLine: { color: COLORS.error },
  inputContainer: { flexDirection: 'row', alignItems: 'center', padding: 10, backgroundColor: COLORS.surface, borderTopWidth: 1, borderTopColor: COLORS.border },
  prompt: { color: COLORS.primary, fontFamily: 'monospace', fontSize: 14, marginRight: 8 },
  input: { flex: 1, color: '#00FF00', fontFamily: 'monospace', fontSize: 14, paddingVertical: 8 },
  runButton: { width: 36, height: 36, borderRadius: 18, backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center', marginLeft: 8 },
  runButtonText: { color: '#000', fontSize: 14 },
});
