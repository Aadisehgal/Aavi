import React, { useState, useEffect } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet,
  Switch, Alert, ActivityIndicator,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NativeModules } from 'react-native';
import VoiceFingerprint from '../VoiceFingerprint';
import aiClient from '../aiClient';
import { COLORS } from '../theme';

const { DeviceControlModule } = NativeModules;

const PROVIDERS = [
  { key: 'openai', label: 'OpenAI', url: 'platform.openai.com/billing', note: 'Billing required, no free tier' },
  { key: 'gemini', label: 'Gemini', url: 'aistudio.google.com/apikey', note: 'Free tier available' },
  { key: 'groq', label: 'Groq', url: 'console.groq.com/keys', note: 'Free tier available' },
];

export default function SettingsScreen() {
  const [wakeWordEnabled, setWakeWordEnabled] = useState(false);
  const [hasFingerprint, setHasFingerprint] = useState(false);
  const [isEnrolling, setIsEnrolling] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [pin, setPin] = useState('');
  const [hasPIN, setHasPIN] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState('groq');
  const [apiKey, setApiKey] = useState('');
  const [accessibilityStatus, setAccessibilityStatus] = useState('Unknown');
  const [notificationStatus, setNotificationStatus] = useState('Unknown');

  useEffect(() => {
    loadSettings();
    checkPermissions();
  }, []);

  const loadSettings = async () => {
    const fp = await VoiceFingerprint.hasFingerprint();
    setHasFingerprint(fp);
    const pinSet = await VoiceFingerprint.hasPIN();
    setHasPIN(pinSet);
    const provider = await AsyncStorage.getItem('@manu_ai_provider');
    if (provider) setSelectedProvider(provider);
    const key = await AsyncStorage.getItem(`@manu_api_key_${provider || 'groq'}`);
    if (key) setApiKey(key);
  };

  const checkPermissions = async () => {
    try {
      await DeviceControlModule.readScreen();
      setAccessibilityStatus('Enabled');
    } catch {
      setAccessibilityStatus('Disabled - Enable in Settings > Accessibility');
    }
    setNotificationStatus('Check system settings');
  };

  const enrollVoice = async () => {
    setIsEnrolling(true);
    const result = await VoiceFingerprint.enrollVoice();
    setIsEnrolling(false);
    if (result.success) {
      setHasFingerprint(true);
      Alert.alert('Success', 'Voice fingerprint enrolled successfully!');
    } else {
      Alert.alert('Error', result.error);
    }
  };

  const verifyVoice = async () => {
    setIsVerifying(true);
    const result = await VoiceFingerprint.verifyVoice();
    setIsVerifying(false);
    if (result.success) {
      Alert.alert('Verification', `Match: ${result.matchScore.toFixed(1)}%\n${result.approved ? 'APPROVED' : 'REJECTED'}`);
    } else {
      Alert.alert('Error', result.error);
    }
  };

  const deleteFingerprint = async () => {
    Alert.alert('Confirm', 'Delete voice fingerprint?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: async () => {
        const result = await VoiceFingerprint.deleteFingerprint();
        if (result.success) setHasFingerprint(false);
        Alert.alert('Done', result.message);
      }},
    ]);
  };

  const savePIN = async () => {
    if (pin.length < 4 || pin.length > 6) {
      Alert.alert('Error', 'PIN must be 4-6 digits');
      return;
    }
    await VoiceFingerprint.setPIN(pin);
    setHasPIN(true);
    setPin('');
    Alert.alert('Success', 'PIN saved');
  };

  const saveProvider = async (provider) => {
    setSelectedProvider(provider);
    await AsyncStorage.setItem('@manu_ai_provider', provider);
    aiClient.setProvider(provider);
    const key = await AsyncStorage.getItem(`@manu_api_key_${provider}`);
    setApiKey(key || '');
  };

  const saveApiKey = async () => {
    await AsyncStorage.setItem(`@manu_api_key_${selectedProvider}`, apiKey);
    aiClient.setApiKey(selectedProvider, apiKey);
    Alert.alert('Success', 'API key saved');
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.header}>Settings</Text>

      {/* Voice Identity */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🎙️ Voice Identity</Text>
        <Text style={styles.statusText}>{hasFingerprint ? '✅ Enrolled' : '❌ Not enrolled'}</Text>
        <TouchableOpacity style={styles.actionButton} onPress={enrollVoice} disabled={isEnrolling}>
          {isEnrolling ? <ActivityIndicator color="#000" /> : <Text style={styles.actionButtonText}>Enroll Voice (4 sec)</Text>}
        </TouchableOpacity>
        <TouchableOpacity style={[styles.actionButton, styles.secondaryButton]} onPress={verifyVoice} disabled={isVerifying}>
          {isVerifying ? <ActivityIndicator color={COLORS.primary} /> : <Text style={[styles.actionButtonText, styles.secondaryText]}>Verify Voice (3 sec)</Text>}
        </TouchableOpacity>
        {hasFingerprint && (
          <TouchableOpacity style={[styles.actionButton, styles.dangerButton]} onPress={deleteFingerprint}>
            <Text style={[styles.actionButtonText, styles.dangerText]}>Delete Fingerprint</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* PIN */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🔐 PIN Fallback</Text>
        <Text style={styles.statusText}>{hasPIN ? '✅ Set' : '❌ Not set'}</Text>
        <TextInput
          style={styles.input}
          value={pin}
          onChangeText={setPin}
          placeholder="4-6 digit PIN"
          placeholderTextColor={COLORS.textSecondary}
          keyboardType="numeric"
          maxLength={6}
          secureTextEntry
        />
        <TouchableOpacity style={styles.actionButton} onPress={savePIN}>
          <Text style={styles.actionButtonText}>Save PIN</Text>
        </TouchableOpacity>
      </View>

      {/* Wake Word */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>👂 Wake Word</Text>
        <View style={styles.row}>
          <Text style={styles.label}>Listen for "Hey Manu"</Text>
          <Switch value={wakeWordEnabled} onValueChange={setWakeWordEnabled}
            trackColor={{ false: COLORS.border, true: COLORS.primary }}
            thumbColor={wakeWordEnabled ? COLORS.primaryDark : '#888'} />
        </View>
      </View>

      {/* AI Provider */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>🤖 AI Provider</Text>
        {PROVIDERS.map(p => (
          <TouchableOpacity key={p.key} style={[styles.providerButton, selectedProvider === p.key && styles.providerSelected]} onPress={() => saveProvider(p.key)}>
            <Text style={[styles.providerLabel, selectedProvider === p.key && styles.providerLabelSelected]}>{p.label}</Text>
            <Text style={styles.providerNote}>{p.note}</Text>
            <Text style={styles.providerUrl}>Get key: {p.url}</Text>
          </TouchableOpacity>
        ))}
        <TextInput
          style={styles.input}
          value={apiKey}
          onChangeText={setApiKey}
          placeholder={`Enter ${selectedProvider} API key`}
          placeholderTextColor={COLORS.textSecondary}
          autoCapitalize="none"
        />
        <TouchableOpacity style={styles.actionButton} onPress={saveApiKey}>
          <Text style={styles.actionButtonText}>Save API Key</Text>
        </TouchableOpacity>
      </View>

      {/* System Status */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>📊 System Status</Text>
        <View style={styles.statusRow}>
          <Text style={styles.statusLabel}>Accessibility:</Text>
          <Text style={[styles.statusValue, accessibilityStatus.includes('Enabled') ? styles.statusGood : styles.statusBad]}>{accessibilityStatus}</Text>
        </View>
        <View style={styles.statusRow}>
          <Text style={styles.statusLabel}>Notification Access:</Text>
          <Text style={styles.statusValue}>{notificationStatus}</Text>
        </View>
      </View>

      {/* Help */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>❓ Help</Text>
        <Text style={styles.helpText}>MANU AI controls YOUR phone only. No remote surveillance. No hidden data transmission.</Text>
        <Text style={styles.helpText}>Without root: Cannot read other apps' private files, cannot bypass permission dialogs, cannot access /data/data/ of other apps.</Text>
        <Text style={styles.helpText}>If a tool requires root, the app will clearly say so. Never fake capabilities.</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  content: { padding: 15, paddingBottom: 40 },
  header: { color: COLORS.primary, fontSize: 28, fontWeight: 'bold', textAlign: 'center', marginBottom: 20 },
  section: { backgroundColor: COLORS.card, borderRadius: 12, padding: 15, marginBottom: 15, borderWidth: 1, borderColor: COLORS.border },
  sectionTitle: { color: COLORS.text, fontSize: 16, fontWeight: 'bold', marginBottom: 12 },
  statusText: { color: COLORS.textSecondary, fontSize: 13, marginBottom: 10 },
  actionButton: { backgroundColor: COLORS.primary, borderRadius: 8, paddingVertical: 12, alignItems: 'center', marginBottom: 8 },
  actionButtonText: { color: '#000', fontWeight: 'bold', fontSize: 14 },
  secondaryButton: { backgroundColor: 'transparent', borderWidth: 1, borderColor: COLORS.primary },
  secondaryText: { color: COLORS.primary },
  dangerButton: { backgroundColor: 'transparent', borderWidth: 1, borderColor: COLORS.error },
  dangerText: { color: COLORS.error },
  input: { backgroundColor: COLORS.background, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 10, color: COLORS.text, fontSize: 14, borderWidth: 1, borderColor: COLORS.border, marginBottom: 10 },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  label: { color: COLORS.text, fontSize: 14 },
  providerButton: { backgroundColor: COLORS.surface, borderRadius: 8, padding: 12, marginBottom: 8, borderWidth: 1, borderColor: COLORS.border },
  providerSelected: { borderColor: COLORS.primary, backgroundColor: 'rgba(0,212,255,0.1)' },
  providerLabel: { color: COLORS.text, fontSize: 14, fontWeight: 'bold' },
  providerLabelSelected: { color: COLORS.primary },
  providerNote: { color: COLORS.textSecondary, fontSize: 11, marginTop: 2 },
  providerUrl: { color: COLORS.primary, fontSize: 10, marginTop: 2 },
  statusRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  statusLabel: { color: COLORS.textSecondary, fontSize: 13 },
  statusValue: { fontSize: 13, fontWeight: 'bold' },
  statusGood: { color: COLORS.success },
  statusBad: { color: COLORS.error },
  helpText: { color: COLORS.textSecondary, fontSize: 12, lineHeight: 18, marginBottom: 8 },
});
