import React, { useEffect, useRef, useState } from 'react';
import {
  InterstitialAd, AdEventType, RewardedAd, RewardedAdEventType,
  AppOpenAd,
} from 'react-native-google-mobile-ads';

const AD_IDS = {
  interstitial: 'ca-app-pub-3684441716460567/4188433698',
  rewarded: 'ca-app-pub-3684441716460567/7885822933',
  appOpen: 'ca-app-pub-3684441716460567/3940256099',
};

const COOLDOWN_MS = 60000;

class AdMobManager {
  constructor() {
    this.lastAdShown = 0;
    this.interstitial = null;
    this.rewarded = null;
    this.appOpen = null;
    this.isRewardedLoaded = false;
  }

  canShowAd() {
    const now = Date.now();
    return now - this.lastAdShown >= COOLDOWN_MS;
  }

  loadInterstitial() {
    this.interstitial = InterstitialAd.createForAdRequest(AD_IDS.interstitial);
    this.interstitial.load();
  }

  showInterstitial(onClosed) {
    if (!this.canShowAd()) {
      onClosed?.();
      return;
    }
    if (!this.interstitial || !this.interstitial.loaded) {
      this.loadInterstitial();
      onClosed?.();
      return;
    }
    this.interstitial.show();
    this.lastAdShown = Date.now();
    this.interstitial.addAdEventListener(AdEventType.CLOSED, () => {
      this.loadInterstitial();
      onClosed?.();
    });
  }

  loadRewarded() {
    this.rewarded = RewardedAd.createForAdRequest(AD_IDS.rewarded);
    this.rewarded.load();
    this.rewarded.addAdEventListener(RewardedAdEventType.LOADED, () => {
      this.isRewardedLoaded = true;
    });
  }

  showRewarded(onRewarded, onClosed) {
    if (!this.rewarded || !this.isRewardedLoaded) {
      this.loadRewarded();
      onClosed?.();
      return;
    }
    this.rewarded.show();
    this.rewarded.addAdEventListener(RewardedAdEventType.EARNED_REWARD, (reward) => {
      onRewarded?.(reward);
    });
    this.rewarded.addAdEventListener(AdEventType.CLOSED, () => {
      this.isRewardedLoaded = false;
      this.loadRewarded();
      onClosed?.();
    });
  }

  loadAppOpen() {
    this.appOpen = AppOpenAd.createForAdRequest(AD_IDS.appOpen);
    this.appOpen.load();
  }

  showAppOpen() {
    if (!this.canShowAd()) return;
    if (!this.appOpen || !this.appOpen.loaded) {
      this.loadAppOpen();
      return;
    }
    this.appOpen.show();
    this.lastAdShown = Date.now();
    this.appOpen.addAdEventListener(AdEventType.CLOSED, () => {
      this.loadAppOpen();
    });
  }
}

export default new AdMobManager();
