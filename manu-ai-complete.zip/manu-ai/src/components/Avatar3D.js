import React from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import { WebView } from 'react-native-webview';

const { width } = Dimensions.get('window');

const GLB_HTML = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { margin: 0; overflow: hidden; background: transparent; }
    #canvas { width: 100%; height: 100%; }
  </style>
</head>
<body>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/loaders/GLTFLoader.js"></script>
  <script>
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
    camera.position.z = 3;
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    document.body.appendChild(renderer.domElement);

    const ambientLight = new THREE.AmbientLight(0x00D4FF, 0.5);
    scene.add(ambientLight);
    const pointLight = new THREE.PointLight(0x00D4FF, 1, 10);
    pointLight.position.set(2, 2, 2);
    scene.add(pointLight);

    let model = null;
    let fallbackMesh = null;

    // Try loading GLB from assets
    const loader = new THREE.GLTFLoader();
    loader.load('file:///android_asset/avatars/manu_avatar.glb',
      function(gltf) {
        model = gltf.scene;
        model.scale.set(0.8, 0.8, 0.8);
        scene.add(model);
        console.log('GLB loaded successfully');
      },
      undefined,
      function(error) {
        console.log('GLB load failed: ' + error.message);
        createFallback();
      }
    );

    function createFallback() {
      const geometry = new THREE.SphereGeometry(0.6, 32, 32);
      const material = new THREE.MeshBasicMaterial({
        color: 0x00D4FF,
        wireframe: true,
        transparent: true,
        opacity: 0.6
      });
      fallbackMesh = new THREE.Mesh(geometry, material);
      scene.add(fallbackMesh);
      console.log('Using procedural fallback sphere');
    }

    // Auto-fallback if GLB takes too long
    setTimeout(function() {
      if (!model && !fallbackMesh) {
        createFallback();
      }
    }, 3000);

    function animate() {
      requestAnimationFrame(animate);
      if (model) {
        model.rotation.y += 0.005;
      }
      if (fallbackMesh) {
        fallbackMesh.rotation.y += 0.01;
        fallbackMesh.rotation.x += 0.005;
      }
      renderer.render(scene, camera);
    }
    animate();
  </script>
</body>
</html>
`;

export default function Avatar3D({ size = 180 }) {
  return (
    <View style={[styles.container, { width: size, height: size }]}>
      <WebView
        originWhitelist={['*']}
        source={{ html: GLB_HTML }}
        style={{ width: size, height: size, backgroundColor: 'transparent' }}
        allowFileAccess={true}
        allowFileAccessFromFileURLs={true}
        allowUniversalAccessFromFileURLs={true}
        javaScriptEnabled={true}
        domStorageEnabled={true}
        scrollEnabled={false}
        bounces={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
  },
});
